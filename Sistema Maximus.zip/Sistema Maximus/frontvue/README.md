# Sistema para consumo de uma API
Esse projeto foi criado com o intuito de consumir uma API Rest que eu criei.

**[ACESSE A DOCUMENTAÇÃO DA API](https://github.com/douglas-ggoncalves/Full-Stack/tree/main/Sistema%20Maximus/backnode)**

## Fotos do projeto
Abaixo demonstro algumas fotos de determinadas telas do sistema.

![Screenshot_1](https://user-images.githubusercontent.com/60992128/174517752-9212f50d-214a-4840-adad-1b154e88b5e4.png)

![Screenshot_2](https://user-images.githubusercontent.com/60992128/174517755-f7c8c68a-827b-40ce-888b-50d589b984fc.png)

![Screenshot_3](https://user-images.githubusercontent.com/60992128/174517757-811a7e69-7bb0-41d3-bcff-4fea2b4ad458.png)

![Screenshot_4](https://user-images.githubusercontent.com/60992128/174517758-9a39f9a8-908f-486d-8fb4-53ba53be1b16.png)

![Screenshot_5](https://user-images.githubusercontent.com/60992128/174517761-08072647-9853-4803-9d24-1a4882c228e5.png)

![Screenshot_6](https://user-images.githubusercontent.com/60992128/174517763-28db8377-a888-42d4-b5b3-d41bed37997e.png)